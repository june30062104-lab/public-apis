# Chuẩn thị giác đã duyệt

## Thứ tự ưu tiên

1. Góp ý mới nhất của người dùng trong phiên đang làm.
2. Phong cách hoạt hình 2D của hai ảnh người dùng gửi: người trong phòng tập và sân nhà đời thường, nhân vật đầu tròn, nét đen, áo quần có diện tích, nền nhiều đồ vật cụ thể.
3. Demo 57,1 giây về charpai, kang/ondol và futon, cộng các cải tiến người dùng yêu cầu dưới đây.
4. Demo 31,2 giây sau sửa điểm tựa, chỉ dùng làm ví dụ phụ.

Không lấy các bản bán hiện thực hoặc bản 2D cũ chưa sửa tư thế làm chuẩn mới.

## Ví dụ đã xuất

- Demo 57 giây: https://github.com/june30062104-lab/public-apis/raw/refs/heads/video-demo-bed-history-20261024/lich-su-chiec-giuong-cartoon-khi-hau-57s.mp4
- Demo 31 giây đã sửa: https://github.com/june30062104-lab/public-apis/raw/refs/heads/video-demo-bed-history-20261024/lich-su-chiec-giuong-cartoon-31s-v2.mp4
- Ảnh trong gói: ../assets/style-reference.jpg

Các ví dụ mô tả phong cách, không ràng buộc dự án mới phải có giường, sân nhà Ấn Độ, kimono, bục sưởi hoặc cùng lời đọc. Không cần tải lại toàn bộ video nếu đã có ảnh tham chiếu và hiểu chuẩn.

## Hình phải giữ

- Viền đen rõ, mảng màu phẳng; một ít bóng để hiểu chiều sâu, không chuyển sang vật liệu ảnh thật.
- Nhân vật giản lược nhưng dễ đọc tư thế: đầu, cổ, vai, khuỷu, hông, gối, bàn chân gắn nhau hợp lý.
- Không gian có mặt sàn, kiến trúc, đồ dùng và vật liệu nhận ra được. Phòng có đồ đạc, xưởng có dụng cụ, ngoài trời có cảnh quan cụ thể.
- Cùng phong cách cho nền, người và đồ vật động; không ghép người ảnh thật vào nền cartoon hoặc ngược lại.
- Ánh sáng, khí hậu và thời điểm trong ngày có tác động rõ đến cảnh; không chỉ thay nhãn Ban đêm lên một nền vẫn sáng như ban ngày.

## Những cải tiến phải áp dụng từ lần tới

- Thêm cảnh zoom in/cắt cận vào đúng vật, bàn tay, động tác hoặc cơ chế quan trọng trong lời đọc.
- Đa dạng tư thế và hành động, không chỉ đứng chỉ tay hoặc dùng cùng một động tác tay cho mọi ý.
- Đa dạng nhân vật và phục trang theo quốc gia, thời kỳ, nghề nghiệp, khí hậu và câu chuyện; giữ sự liên tục của cùng nhân vật.
- SFX nhẹ tại các chuyển cảnh có ý nghĩa, không chồng âm hoặc lặp whoosh lớn liên tục.
- Khi chỉ nhận góp ý/cập nhật skill, ghi quy tắc; không dựng lại video đã duyệt nếu người dùng nói không cần dựng lại.

## Bài học từ lỗi đã xảy ra

Một cảnh nằm cũ bị nhìn như bay vì xoay/nâng thân mà không giữ điểm chống tay và chân. Bóng sai cùng các mảng xanh phía dưới làm vấn đề rõ hơn. Cách sửa đúng là dựng lại tư thế có mặt đỡ, giữ cơ thể ổn định và chỉ animate phần thực sự cần phản ứng, sau đó đặt lại bóng.

Ở các cảnh khác, phải kiểm tra cả vật nhỏ: ấm trà phải nằm trên mặt bàn; tay mang đồ phải nắm đúng đầu vật; quần áo và đường chân không được tạo thành một nét rỗng khiến nhân vật trông như ngồi trên không.

Không coi sửa màu hoặc thêm bóng là đủ để chữa một cấu trúc tư thế sai.
