# Công thức cảnh, nhân vật và camera

## 1. Lập bảng thế giới trước khi tạo tài sản

Với mỗi chương/đơn vị ý, ghi:

- Địa điểm, quốc gia/vùng và mức độ chính xác cần thiết.
- Thời kỳ hoặc thời gian trong ngày; khí hậu và hoạt động chính.
- Kiến trúc, vật liệu, mặt sàn, cửa, dụng cụ và các vật lặp lại.
- Nhân vật: vai trò, tuổi, nghề, tóc/mũ, trang phục, giày dép, đạo cụ.
- Chi tiết nào được kịch bản xác nhận, chi tiết nào cần tra cứu hoặc chỉ là minh họa.

Ví dụ cách suy nghĩ: một cảnh thợ đan ở nơi nóng cần tư thế làm việc, dây, bóng râm và đồ mặc thích hợp; một cảnh trong nhà mùa đông cần thiết kế giữ ấm và lớp quần áo khác. Không mặc cùng áo phông xanh cho mọi nhân vật lịch sử. Áo xanh có thể là người dẫn chuyện riêng nếu câu chuyện cần người dẫn.

Dùng nguồn đáng tin cho phục trang/kiến trúc quan trọng. Không tự nhận minh họa là chân dung hoặc phục dựng khảo cổ chính xác. Không thêm thông tin lịch sử chưa có trong kịch bản chỉ để làm cảnh đẹp.

## 2. Chuỗi cảnh phục vụ một ý

Thiết lập địa điểm → cho nhân vật bắt đầu việc → cắt cận tay/vật/cơ chế → đổi trạng thái → trở lại kết quả.

Không buộc mọi câu thoại dùng đủ năm bước. Chọn bước có ích; ưu tiên điểm cắt ở đổi ý, từ khóa và hành động hoàn tất.

Cụm cảnh gợi ý:

- Sinh hoạt: toàn cảnh phòng/sân → trung cảnh người → cận vật quen thuộc → phản ứng.
- Chế tác: xưởng → cầm dụng cụ → đặc tả điểm chạm → vật hoàn thành/đang đổi trạng thái.
- Cơ chế: vật trong môi trường → zoom vào bộ phận → mặt cắt hoặc luồng chuyển động → hệ quả nhìn thấy được.
- So sánh: hai hoàn cảnh cụ thể → hai hành động khác nhau → sơ đồ ngắn để chốt khác biệt.
- Lịch sử: bản đồ/mốc khi cần → người, phục trang và không gian thời kỳ đó → vật hoặc hành động gắn với luận điểm.

## 3. Kế hoạch cảnh cận

Trong shot list, ghi rõ tiêu điểm, khung cận, điểm neo, thời điểm vào/ra và lý do.

Ví dụ tiêu điểm: đầu ngón tay kéo dây, khớp gỗ, bản lề, góc tấm vải, nước chảy vào cốc, bánh xe, vật liệu chịu lực. Không ghi mỗi chữ zoom mà không xác định vật đang được nhìn.

- Cắt cận trực tiếp nếu muốn nhấn thao tác ngay.
- Zoom vào theo trục vật nếu cần duy trì quan hệ không gian.
- Pan từ A sang B khi câu nói giải thích quan hệ giữa chúng.
- Có thể làm insert cận độc lập để đủ chi tiết thay vì phóng quá lớn nền ảnh nhỏ.
- Giữ đối tượng trong khung và chữ đứng yên lúc cần đọc. Nhãn màn hình không bị camera kéo khỏi khung.

Preset để thử, không phải thông số đo từ mẫu:

- Zoom/cắt nối vào chi tiết: khoảng 0,35–0,7 giây.
- Cỡ cận thường cần 1,2–1,7 lần toàn cảnh, tùy tài sản; không coi đây là giới hạn cố định.
- Giữ cận khoảng 1,5–4 giây hoặc theo thời lượng thao tác/voice.
- Push-in nhẹ 1,00 → 1,05–1,10 chỉ là một lựa chọn, không áp dụng cho mọi cảnh.

## 4. Thiết kế hành động và tư thế

Mỗi cảnh phải có câu trả lời cho: ai làm gì với vật nào, lực/ý định đi đâu, điểm tiếp xúc nào giữ nguyên, kết quả nào xuất hiện.

Đổi ít nhất một yếu tố có nghĩa khi cùng bối cảnh tiếp tục lâu: tư thế, hướng nhìn, bộ phận thao tác, vật được cầm, trạng thái vật hoặc cỡ cảnh. Không làm mọi lớp rung/trượt chỉ để tạo cảm giác động.

Bộ tư thế nên bao gồm các hành động cần cho riêng kịch bản. Không tạo trước một bộ đi–đứng–chỉ tay rồi gán vào mọi câu chuyện. Lên riêng tư thế ngồi/quỳ/nằm hoặc thao tác phức tạp; nếu chỉ có một ảnh phẳng thì không giả nhận đã rig toàn thân.

Giữ người và đạo cụ có kích thước hợp không gian. Khác biệt phục trang không thay thế cho khác biệt hành động. Không sao chép nguyên một nhân vật sang cả nhóm nếu cảnh không có lý do.

## 5. Prompt nền gợi ý

Hoạt hình giải thích 2D màu phẳng, viền đen rõ và đồng bộ. Bối cảnh [địa điểm/quốc gia] vào [thời kỳ/thời gian], có [kiến trúc], [vật liệu], [đồ dùng], phối cảnh cụ thể và mặt sàn rõ. Chừa vị trí cho [nhân vật/hành động] tại [vị trí]. Không có sẵn [người/đạo cụ sẽ animate]. Không chữ, không logo. Không ảnh thật, không 3D, không texture vẽ màu. Giữ khoảng trống vừa đủ cho hành động, không biến nền thành phòng trống.

Điền theo kịch bản, không bê nguyên nội dung ví dụ giường sang dự án khác. Nếu kết quả vẫn có chất liệu ảnh thật hoặc lẫn phong cách, sửa tài sản trước khi dựng dài.

## 6. Chuyển cảnh và chữ

Chuyển cảnh phải có lý do: đổi địa điểm, thời gian, góc nhìn, quan hệ cơ chế hoặc kết quả hành động. Cut thẳng thường đủ; wipe/mở tròn/zoom nối dùng chọn lọc. Không dùng một hiệu ứng cho mọi chuyển cảnh.

Chữ chỉ làm rõ tên vật, địa điểm, thời kỳ, số liệu hoặc ý chính. Đo chiều rộng thực tế của font, giữ lề và khoảng cách giữa các nhãn dưới icon. Không dựa vào ước lượng số ký tự rồi bỏ qua kiểm tra ảnh xuất. Cận cảnh không được che điểm chạm bằng chữ hoặc vòng khoanh.
