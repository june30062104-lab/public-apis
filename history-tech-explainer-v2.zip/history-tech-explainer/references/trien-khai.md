# Triển khai chuyển động, âm thanh và kiểm tra

## Chọn công cụ và bảo toàn đầu vào

Dùng Remotion/SVG, HyperFrames hoặc phần mềm biên tập phù hợp khả năng thực tế. Skill là quy trình, không phải renderer. Dùng tài sản tách lớp khi cần chuyển động độc lập; đặt tên theo scene và layer. Giữ voice gốc, phiên bản đã duyệt và nguồn dự án.

Thời lượng xuất lấy từ audio thực. Với demo, chọn điểm đầu/cuối trọn câu, để dư đuôi hợp lý trước câu tiếp theo. Không kéo thành thời lượng trong tên tệp hoặc cắt mất âm cuối.

## Hợp đồng điểm tiếp xúc

Ghi điểm neo trong shot list, theo tọa độ cảnh thay vì chỉ theo ảnh.

- Đi: xét bàn chân sau mọi biến đổi; ít nhất điểm đặt chân của pha chống phải ở mặt đất. Bù độ cao khi xoay chân nếu rig đòi hỏi, không để cả hai chân liên tục treo trên nền.
- Ngồi/quỳ: xác định mặt đỡ cho hông, đùi, gối, bàn chân; nối đầy đủ đầu–cổ–thân–chi. Không dùng nét quần cong rỗng để thay một khối đùi/cẳng chân thiếu.
- Nằm: đầu, cẳng tay, vai/hông và chân có điểm đỡ phù hợp. Nếu phản ứng chỉ cần mắt và một tay, không tự nâng cả thân. Muốn ngồi dậy phải dựng riêng chuyển động có điểm chống.
- Bê/cầm: đạo cụ dùng cùng hệ biến đổi với điểm nắm. Hai người bê một vật dùng chung nhịp và các điểm nắm kiểm tra được; không cho vật bob riêng khỏi tay.
- Bản lề/gấp/kéo: quay quanh khớp thật của đạo cụ và giữ phần neo. Không kéo cả ảnh làm vật bay hoặc biến mất qua người.
- Rót/đặt: cốc, bình và mặt bàn có tọa độ tiếp xúc; dòng chất lỏng nối đúng vòi và miệng cốc. Vật đặt xong phải có mặt đỡ và bóng phù hợp.

Bóng tiếp xúc nằm sát bề mặt và không chạy theo tay đang vẫy. Chỉ rung/thở/bob rất nhỏ khi không làm phá điểm đỡ. Giữ thứ tự che khuất: bàn tay ôm vật, chân trước/sau, mép giường che phần cần che. Kiểm tra viền alpha trên nền tương phản.

## Timeline và camera

Dựng theo frame/thời gian xác định, không dùng animation thời gian thực không thể tái hiện khi render. Ở Remotion, lấy frame và fps từ composition; ở công cụ khác dùng cơ chế timeline tương đương.

Cận cảnh phải có điểm neo. Giới hạn camera theo biên nền hoặc chuẩn bị đủ ảnh dư; không để lộ vùng đen/trống ở mép trong pan/zoom. Giữ nhãn màn hình trong lề an toàn. Nếu chỉ có nền phẳng, không gọi pan/crop là parallax nhiều lớp.

Dùng thay đổi có nghĩa trong cảnh dài: một sợi dây được đan, bộ phận chịu lực đổi trạng thái, đường nhiệt chạy tới nơi cần giải thích, tay gấp một góc vải. Không animate mọi thứ cùng lúc hoặc dùng zoom để giấu việc thiếu hành động.

## SFX chuyển cảnh có tiết chế

Mỗi điểm chuyển cảnh có trường SFX trong shot list. Có ba cách hợp lệ:

1. Một SFX nhẹ cho đổi cảnh/đổi ý rõ.
2. Nối bằng âm hành động hoặc ambience đang có.
3. Chủ động im lặng để giữ nhịp tự nhiên, ghi lý do khi đó là lựa chọn tốt hơn.

Không tự bỏ qua thiết kế âm ở các điểm cắt. Không biến yêu cầu thêm SFX thành whoosh lớn ở mọi cut nhỏ. Không chồng whoosh, impact, pop và click cùng một điểm nếu một âm đã đủ. Với chuỗi cut nhanh, có thể dùng một cầu âm thanh chung.

Chọn bảng âm nhỏ, biến thể vừa đủ: vải/giấy, gỗ, bước chân, chuyển động mềm, kim loại hoặc âm môi trường phù hợp vật/cảnh. Căn transient vào lúc chạm, gấp, đặt, đóng hoặc hoàn tất chuyển cảnh. Tránh âm kỹ thuật số không hợp bối cảnh lịch sử khi không có ý đồ giải thích.

Giữ voice là ưu tiên. Có thể thử SFX/nhạc thấp hơn voice khoảng 18–26 dB rồi chỉnh theo nội dung; đây là preset làm việc, không phải số đo mẫu. Duck âm dưới câu nói, taper đầu/cuối để tránh click. Mặc định không thêm nhạc chỉ để lấp chỗ trống. Không nhận định đã nghe mix khi chưa nghe được.

## Kiểm tra bắt buộc trước bàn giao

- Nội dung: đủ đoạn voice đã chọn/toàn bộ voice được yêu cầu; số liệu và độ chắc chắn đúng lời đọc.
- Phong cách: nền, người và đồ vật đều 2D viền đen/màu phẳng; địa điểm, thời kỳ, phục trang và đạo cụ hợp cảnh.
- Nhịp: có toàn–trung–cận theo nhu cầu; cận đúng đồ vật/hành động, không chỉ zoom vào toàn cảnh trống.
- Cơ thể: đầu–cổ–thân và các chi nối hợp lý; kiểm tra trước/giữa/sau chuyển tư thế, không chỉ khung đẹp nhất.
- Tiếp xúc: tay–vật, chân/gối/hông–mặt đỡ, vật–mặt bàn và bóng; không xuyên vật, tách tay hoặc lơ lửng.
- Chuyển cảnh: hướng/mốc nối rõ, không nháy ngoài ý muốn, không lộ mép nền, chữ không mất khỏi khung.
- Âm: voice rõ, SFX đúng chỗ và không lấn lời; kiểm tra đầu/âm cuối, loudness và true peak.
- Chữ: font Việt đủ dấu, đúng chính tả, không chồng nhãn, không che tiêu điểm; giữ số và mốc theo kịch bản.
- Tệp: kiểm tra file vừa xuất đúng run, đúng số frame/thời lượng, độ phân giải/fps/codec và giải mã không lỗi. Không dùng một file cũ còn sót làm bằng chứng render mới đã thành công.

Mặc định MP4 H.264, 1080p, 30 fps, audio AAC. Có thể nhắm khoảng -16 đến -14 LUFS integrated và true peak không quá -1 dBTP, tùy nền tảng. Không hạ chất lượng hoặc đổi fps mà không có lý do phù hợp mục tiêu.

Xem chuyển động và nghe tốc độ thực khi có công cụ. Dùng thêm contact sheet và chuỗi khung ở các tư thế rủi ro để tìm lỗi. Contact sheet không chứng minh đã nghe hoặc xem video tốc độ thực; báo đúng giới hạn kiểm tra.

Khi đã kiểm tra, cung cấp link tải; thử tải và đối chiếu dung lượng/checksum khi có thể. Lưu shot list và lệnh chạy lại. Chỉ dùng dịch vụ ngoài mà người dùng đã yêu cầu/cho phép trong bối cảnh hiện tại.
